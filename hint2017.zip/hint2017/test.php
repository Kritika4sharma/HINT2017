<?php 

// $command = escapeshellcmd('/home/adeora7/HINT17/test.py');
// $output = shell_exec($command);
// echo exec("ifconfig");
exec('python3 /home/adeora7/HINT17/camera.py', $outputAndErrors, $return_value);
// echo exec('python3 /home/adeora7/HINT17/texttospeech.py');
// passthru('python3 /var/www/camera.py');
print_r( $outputAndErrors[0]);
// echo $output;

?>