<html>
<head></head>

<body>


<button onclick="func()">Click</button>
<button onclick="func()">Walk</button>

</script>

</body>
</html>

<?php

	// header('Location: test.php');
?>